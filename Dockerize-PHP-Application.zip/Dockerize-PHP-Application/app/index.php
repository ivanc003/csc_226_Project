<html>
<head>
    <title>PHP Test</title>
</head>
<body>
<?php
$txt = "Hello world!";
$x = 5;
$y = 10.5;

echo $txt;
echo '</br>';
echo $x;
//echo '<p>Hello World</p>';
myTest($x);
//var_dump($x);
function myTest($scopeTest) {
    echo "Study PHP at " . $scopeTest . '</br>';
    echo "<p>Variable x inside function is: $scopeTest</p>";
}

    echo '<span style="color: black; font-size: 20px;">Welcome ';


?>
</body>
</html>