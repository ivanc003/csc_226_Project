import logo from './logo.svg';
import './App.css';
import MyComponent from "./components/MyComponent";
import Game from "./components/Game";
import Card from '@mui/material/Card';
import BasicCard from "./components/card";
import Button from "@mui/material/Button";
import {useEffect, useState} from "react";

function App() {
    const [data, setData] = useState(null);
  return (
    <div className="App">

        <Card variant="outlined">Explore the World</Card>
        <BasicCard></BasicCard>
        <Button
            onClick={() => {
                alert('clicked');
                    fetch('http://localhost/api/read.php?client_id=vebG0dLYa4T1dot7y2riaPTQxMznG81QevRU_k8AfBk&query=chinatown&count=1')//localhost
                        .then(response => response.json())
                        .then(data => setData(data));
            }}
        >
            Click me
        </Button>
        {JSON.stringify(data)}

    </div>
  );
}

export default App;
